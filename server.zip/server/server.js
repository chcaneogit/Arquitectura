const express = require('express');
const cors = require('cors');
const sgMail = require('@sendgrid/mail');
const twilio = require('twilio');

const app = express();
const PORT = process.env.PORT || 3000; // Asegúrate de que el puerto sea 8080

// Configura SendGrid con tu clave API
sgMail.setApiKey('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');

// Configura Twilio con tu Account SID y Auth Token
const accountSid = 'AC351ab2e1bd2bc4e894eba99bf5b17608'; // Reemplaza con tu Account SID de Twilio
const authToken = '4edaf26e348afaf351a0e3f6da5443a7'; // Reemplaza con tu Auth Token de Twilio
const client = twilio(accountSid, authToken);

// Configura CORS
app.use(cors({
  origin: '*', // Permitir solicitudes de cualquier origen
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true,
}));

app.use(express.json());

// Ruta para enviar correos
app.post('/send-email', async (req, res) => {
  const { to, subject, text } = req.body;
  const msg = {
    to: to,
    from: 'caneovilches46@gmail.com', // Asegúrate de que este correo esté verificado en SendGrid
    subject: subject,
    text: text,
    html: `<p>${text}</p>`,
  };

  try {
    console.log('Enviando correo a:', to);
    await sgMail.send(msg);
    res.status(200).send({ message: 'Correo enviado con éxito' });
  } catch (error) {
    console.error('Error al enviar el correo:', error);
    res.status(500).send({ error: 'Error al enviar el correo' });
  }
});

// Ruta para enviar SMS usando Twilio
app.post('/send-sms', async (req, res) => {
  const { to, message } = req.body;

  try {
    console.log('Enviando SMS a:', to);
    const sms = await client.messages.create({
      body: message,
      from: '+15205829398', // Número de teléfono de Twilio
      to: to,
    });
    res.status(200).send({ message: 'SMS enviado con éxito', sid: sms.sid });
  } catch (error) {
    console.error('Error al enviar el SMS:', error);
    res.status(500).send({ error: 'Error al enviar el SMS' });
  }
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor en funcionamiento en http://0.0.0.0:${PORT}`); // Escucha en todas las interfaces
});
